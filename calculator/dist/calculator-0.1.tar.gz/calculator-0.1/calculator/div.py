def div(a, b):
    if b == 0:
        raise ZeroDivisionError("You cannot divide by zero")
    else:
        return a / b